angular.module('app', []);


angular.module('app').controller('CalculationCtrl', function($scope){
    var self = this;

    self.designCost = 0;
    self.addSlider = 0;
    self.sliderNumber = 0;
    self.sliderPrice = 100;
    self.message = 'You can pick up to 20 sliders.';
    self.summary = '$0';


    self.updateSummary = function(){
        self.summary = '$' + ( self.designCost + self.addSlider + ( self.sliderNumber * self.sliderPrice ) );
    }
    $scope.calculation.change = function(val, param){
        switch(param) {
            case 0:
                if( val === true && self.designCost === 0 ) {
                    self.designCost = 500;
                    self.updateSummary();
                } else if( val == false && self.designCost > 0 ) {
                    self.designCost = 0;
                    self.updateSummary();
                }
                break;
            case 1:
                if( val === true && self.addSlider === 0 ) {
                    self.addSlider = 300;
                    self.updateSummary();
                } else if ( val === false && self.addSlider > 0 ) {
                    self.addSlider = 0;
                    self.updateSummary();
                }
                break;
            case 2:
                console.log(self.message);
                console.log(val);
                if( val >= 0 && val <= 20 ) {
                    self.sliderNumber = val;
                    self.message = '';
                    self.updateSummary();
                } else  {
                    self.message = 'You can pick up to 20 sliders.'
                }
                break;
            default:
                break;
        }

    };

});