var gulp = require('gulp');

var eslint = require('gulp-eslint');
var sass = require('gulp-sass');
var cleanCSS = require('gulp-clean-css');
var lintsass = require('gulp-sass-lint');
var sourcemaps = require('gulp-sourcemaps');
var concat = require('gulp-concat');
var uglify = require('gulp-uglify');
var rename = require('gulp-rename');

// gulp tasks
// lint and check js for errors
gulp.task('eslint', function() {
    return gulp.src('scripts/**/*.js')
        .pipe(eslint())
        .pipe(eslint.format())
        .pipe(eslint.failAfterError());
});

// run sass compiler and create one css file 'template.css'
gulp.task('sass', function() {
    return gulp.src('sass/**/*.scss')
        .pipe(lintsass({
            options: {
                formatter: 'stylish',
                'merge-default-rules': false
            },
            // linter rules
            rules: {
                'no-ids': 2,
                'indentation': [
                    2,
                    {
                        'size': 4
                    }
                ],
                'no-important': 2,
                'brace-style': '1tbs',
                'hex-notation': 1,
                'no-color-keywords': 2,
                'leading-zero': [
                    1,
                    {
                        'include': 'true'
                    }
                ],
                'bem-depth': [
                    1,
                    {
                        'max-depth': 2
                    }
                ],
                'nesting-depth': [
                    1,
                    {
                        'max-depth': 4
                    }
                ],
                'space-after-colon': 1,
                'space-before-brace': 1,
                'space-around-operator': 1,
                'zero-unit': 1,
                'final-newline': 2,
                'property-sort-order': [
                    1,
                    {
                        'order': [
                            // positioning
                            'position',
                            'top',
                            'right',
                            'bottom',
                            'left',
                            'display',
                            'float',
                            'clear',
                            // flexbox
                            'flex',
                            'flex-basis',
                            'flex-direction',
                            'flex-flow',
                            'flex-grow',
                            'flex-shrink',
                            'flex-wrap',
                            'justify-content',
                            'justify-items',
                            'justify-self',
                            'align-items',
                            'align-content',
                            'align-self',
                            'order',
                            // layout
                            'width',
                            'height',
                            'min-width',
                            'min-height',
                            'max-width',
                            'max-height',
                            'margin',
                            'margin-top',
                            'margin-right',
                            'margin-bottom',
                            'margin-left',
                            'padding',
                            'padding-top',
                            'padding-right',
                            'padding-bottom',
                            'padding-left',
                            'border',
                            'border-top',
                            'border-right',
                            'border-bottom',
                            'border-left',
                            'border-color',
                            // decoration
                            'color',
                            'background',
                            'background-color',
                            'background-position',
                            'background-size',
                            'opacity',
                            // typography
                            'font',
                            'font-family',
                            'font-size',
                            'font-weight',
                            'list-style',
                            'outline',
                            'text-align',
                            // enhancements
                            'transform',
                            'transition',
                            'box-shadow'
                        ]
                    }
                ]
            }
        }))
        .pipe(lintsass.format())
        .pipe(lintsass.failOnError())
        .pipe(sass())
        .pipe(concat('template.css'))
        .pipe(gulp.dest('dist/css'))
        .pipe(sourcemaps.init())
        .pipe(cleanCSS())
        .pipe(rename('template.min.css'))
        .pipe(sourcemaps.write('../maps'))
        .pipe(gulp.dest('dist/css'));
});

// run js compiler and create one minified file 'template.js'
gulp.task('scripts', function() {
    return gulp.src('scripts/global/**/*.js')
        .pipe(concat('template.js'))
        .pipe(gulp.dest('dist/js'))
        .pipe(rename('template.min.js'))
        .pipe(uglify())
        .pipe(gulp.dest('dist/js'));
});

gulp.task('customscripts', function() {
    return gulp.src('scripts/custom/**/*.js')
        .pipe(gulp.dest('dist/js'));
});

// watch files for changes
gulp.task('watch', function() {
    gulp.watch('scripts/**/*.js', ['eslint', 'scripts']);
    gulp.watch('sass/**/*.scss', ['sass']);
});

// default task
gulp.task('default', ['eslint', 'sass', 'scripts', 'customscripts', 'watch']);