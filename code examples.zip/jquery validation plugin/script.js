(function( $ ) {
    // apply plugin name and function
    $.fn.validateForm = function() {
        // global check for submitting a form
        var check = false;
        var elements = [];
        // go through elements passed with invocation
        this.each(function(){
            // store this for future usage
            var self = this;
            // store children of passed element
            elements.push($(this).find('*'));

            // submit button behaviour

            // on click function
            $(this).find('input[type="submit"]').click(function(e){
                // prevent default action - submit
                e.preventDefault();
                // pass validation result
                check = validateThem();

                // if result is true submit form else add message for user
                if(check == true){
                    if($('.alert').length > 0){
                        $('.alert').remove();
                    }
                    self.submit();
                }else{
                    if($('.alert').length == 0){
                        $('<p class="alert">Please fill out marked form fields!</p>').insertBefore(self);
                    }
                }

            })
        })
        // validation function
        function validateThem(){
            // particular item of a form
            var item;
            // global status for validation
            var status;
            // go through elements of a form
            for(var i=0; i<elements[0].length; i++){
                item = elements[0][i];
                // find a particular types of elements
                // like selects, email, textarea or checkbox
                // if an element's value is not valid, add validate class - which shows red border for user
                // and set status of validation to false
                switch(item.type){
                    case 'select-one':
                        console.log($(item).find('option:selected').val());
                        if($(item).find('option:selected').val().length<=0){
                            $(item).addClass('validate');
                            status = false;
                        }else{
                            resetField($(item));
                        }
                        break;
                    case 'select-multiple':
                        if($(item).find('option:selected').val().length<=0){
                            $(item).addClass('validate');
                            status = false;
                        }else{
                            resetField($(item));
                        }
                        break;
                    case 'email':
                        // regexp for email validation
                        // basic usage, follows structure like a-z@a-z.a-z
                        if($(item).val().match(/^[A-Z][a-z]+[@]+[A-Z][a-z]+[.]+[A-Z][a-z]/gi) == null){
                            $(item).addClass('validate');
                            status = false;
                        }else{
                            resetField($(item));
                        }
                        break;
                    case 'textarea':
                        if($(item).val().length<=0){
                            $(item).addClass('validate');
                            status = false;
                        }else{
                            resetField($(item));
                        }
                        break;
                    case 'checkbox':
                        if($(item).is(':checked') == false){
                            // add validate class to item's sibling - which is label in that case
                            // it is to show that this field is not checked
                            $(item).next('label').addClass('validate');
                            status = false;
                        }else{
                            resetField($(item).next());
                        }
                        break;
                    default:
                        break;
                }
                // reset fields - deletes validate class if a field is filled properly
                function resetField(param){
                    if($(param).hasClass('validate')){
                        $(param).removeClass('validate');
                    }
                }
            }
            if(status == false){
                // todo fix

                return false;
            }else{
                return true;
            }
        }
        return this;
    };
}( jQuery ));



// todo fix
$(document).ready(function(){
    // apply validation to a particular form
    $('form').validateForm();
})