1. start with node server.js

2. rest commands:

get list of users
http://localhost:8081/listUsers

get by id
http://localhost:8081/1
http://localhost:8081/2
http://localhost:8081/3