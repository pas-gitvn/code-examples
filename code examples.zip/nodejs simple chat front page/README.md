1. open a project
2. use command node global.js in a terminal
3. open as many windows as you want on localhost:3000 address
4. enjoy a conversation