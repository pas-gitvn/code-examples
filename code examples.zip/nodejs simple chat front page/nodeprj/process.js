//console.log(process.argv);
process.stdout.write('Ask me a question');