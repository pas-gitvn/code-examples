function assert(test, message){
    var parentDiv = document.getElementById('test');
    var el = document.createElement('span');
    var message = message + ': ';
    var tNode;
    if(test){
        message += 'It works great!';
    }else{
        message += 'Failed';
    }
    tNode = document.createTextNode(message);
    el.appendChild(tNode);
    parentDiv.appendChild(el);
}


function add(n1, n2){
	return n1 + n2;
}



assert(add(5,3) == 3, 'checking');
assert(add(2,3) == 5, 'checking again');