function doMath(){
  var args = Array.prototype.slice.call(arguments);
  var operation = null;
  for(var i=0; i<args.length; i++){
    if(typeof args[i] == 'object'){
      for(var j in args[i]){
        if(j=='what') operation = args[i][j];
      }
    }
  }

  if(operation == 'add') return function(){
   var temp = 0;
   for(var i=0; i<args.length; i++){    
    if(typeof args[i] != 'object'){
       temp+=args[i];
    }
   }
   return operation+' result = '+temp;
  }()

if(operation == 'multiply') return function(){
   var temp = null;
   for(var i=0; i<args.length; i++){    
    if(typeof args[i] != 'object'){
       if(temp == null){
         temp = args[i];
       }else{
         temp *= args[i];
       }              
    }
   }
   return operation+' result = '+temp;
  }()
}

var el = document.createTextNode(doMath(3, 5, {what: 'multiply'}, 6, 7, 23, 25, 55));
document.getElementById('results').appendChild(el);
